import React from "react";
import { FlatList, View, Image, TouchableOpacity, StyleSheet } from "react-native";
import ScreenContainer from "../components/ScreenContainer";
import AppText from "../components/AppText";
import { spacing } from "../theme/spacing";
import { colors } from "../theme/colors";

type MatchItem = {
  id: string;
  name: string;
  message: string;
  avatar: string;
};

const data: MatchItem[] = [
  {
    id: "1",
    name: "Sarah",
    message: "See you later?",
    avatar: "https://placehold.co/60x60",
  },
];

type Props = {
  navigation: any;
};

export default function ChatListScreen({ navigation }: Props) {
  return (
    <ScreenContainer>
      <AppText style={styles.title}>Messages</AppText>

      <FlatList
        data={data}
        keyExtractor={(i) => i.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.row}
            onPress={() => navigation.navigate("Chat", { matchId: item.id, name: item.name })}
          >
            <Image source={{ uri: item.avatar }} style={styles.avatar} />
            <View>
              <AppText>{item.name}</AppText>
              <AppText style={styles.msg}>{item.message}</AppText>
            </View>
          </TouchableOpacity>
        )}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 22, fontWeight: "700", marginVertical: spacing.md },
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: spacing.md,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: spacing.md,
  },
  msg: { color: colors.textMuted, fontSize: 12 },
});
