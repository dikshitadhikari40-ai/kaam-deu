import React, { useState } from "react";
import { View, StyleSheet, Switch } from "react-native";
import ScreenContainer from "../components/ScreenContainer";
import AppText from "../components/AppText";
import { spacing } from "../theme/spacing";
import { colors } from "../theme/colors";

export default function SettingsScreen() {
  const [notifMatches, setNotifMatches] = useState(true);
  const [notifMessages, setNotifMessages] = useState(true);

  return (
    <ScreenContainer>
      <AppText style={styles.title}>Settings</AppText>

      <View style={styles.row}>
        <AppText>New Matches</AppText>
        <Switch
          value={notifMatches}
          onValueChange={setNotifMatches}
          thumbColor={colors.primary}
        />
      </View>

      <View style={styles.row}>
        <AppText>New Messages</AppText>
        <Switch
          value={notifMessages}
          onValueChange={setNotifMessages}
          thumbColor={colors.primary}
        />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 22, fontWeight: "700", marginVertical: spacing.md },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderColor: colors.border,
  },
});
