import React from "react";
import { View, StyleSheet, Image, TouchableOpacity } from "react-native";
import ScreenContainer from "../components/ScreenContainer";
import AppText from "../components/AppText";
import { spacing } from "../theme/spacing";
import { colors } from "../theme/colors";

export default function FeedScreen() {
  return (
    <ScreenContainer>
      <AppText style={styles.header}>Discover</AppText>

      <View style={styles.card}>
        <Image
          source={{
            uri: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg",
          }}
          style={styles.image}
        />

        <View style={styles.bottom}>
          <AppText style={styles.name}>Alex, 25</AppText>
          <AppText style={styles.bio}>Coffee, books, adventures.</AppText>
        </View>
      </View>

      <View style={styles.buttons}>
        <TouchableOpacity style={styles.btn}><AppText>✕</AppText></TouchableOpacity>
        <TouchableOpacity style={styles.btn}><AppText>♥</AppText></TouchableOpacity>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { fontSize: 22, fontWeight: "700", marginVertical: spacing.md },
  card: {
    flex: 1,
    borderRadius: 16,
    overflow: "hidden",
    backgroundColor: colors.card,
  },
  image: { width: "100%", height: "70%" },
  bottom: { padding: spacing.md },
  name: { fontSize: 20, fontWeight: "700" },
  bio: { marginTop: spacing.xs },
  buttons: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: spacing.lg,
  },
  btn: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: colors.card,
    justifyContent: "center",
    alignItems: "center",
  },
});
