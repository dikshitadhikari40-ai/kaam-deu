import React from "react";
import { ScrollView, View, StyleSheet } from "react-native";
import ScreenContainer from "../components/ScreenContainer";
import AppText from "../components/AppText";
import AppButton from "../components/AppButton";
import { spacing } from "../theme/spacing";
import { colors } from "../theme/colors";

export default function ProfileScreen() {
  return (
    <ScreenContainer>
      <ScrollView style={{ paddingTop: spacing.md }}>
        <AppText style={styles.title}>Your Profile</AppText>

        <View style={styles.photoPlaceholder}>
          <AppText>Add Photos Here</AppText>
        </View>

        <AppText style={styles.section}>Basic Info</AppText>
        <AppText>Name, Age, Gender...</AppText>

        <AppText style={styles.section}>Bio</AppText>
        <AppText>Write something about yourself…</AppText>

        <AppText style={styles.section}>Preferences</AppText>
        <AppText>Age Range, Distance, etc.</AppText>

        <AppButton title="Save Profile" onPress={() => {}} style={{ marginTop: spacing.lg }} />
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  title: {
    fontSize: 22,
    fontWeight: "700",
    marginBottom: spacing.md,
  },
  section: {
    marginTop: spacing.lg,
    fontSize: 16,
    fontWeight: "600",
  },
  photoPlaceholder: {
    height: 160,
    borderRadius: 12,
    backgroundColor: colors.card,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: spacing.md,
  },
});
