import React, { useState } from "react";
import { View, TextInput, FlatList, StyleSheet, TouchableOpacity } from "react-native";
import ScreenContainer from "../components/ScreenContainer";
import AppText from "../components/AppText";
import { colors } from "../theme/colors";
import { spacing } from "../theme/spacing";

type Message = {
  id: string;
  text: string;
  mine: boolean;
};

type Props = {
  route: any;
};

export default function ChatScreen({ route }: Props) {
  const { name } = route.params;
  const [messages, setMessages] = useState<Message[]>([
    { id: "1", text: "Hello 👋", mine: false },
    { id: "2", text: "Hi! How are you?", mine: true },
  ]);
  const [input, setInput] = useState("");

  const send = () => {
    if (!input.trim()) return;
    setMessages([...messages, { id: Date.now().toString(), text: input.trim(), mine: true }]);
    setInput("");
  };

  return (
    <ScreenContainer>
      <AppText style={styles.header}>{name}</AppText>

      <FlatList
        data={messages}
        keyExtractor={(i) => i.id}
        contentContainerStyle={{ flexGrow: 1 }}
        renderItem={({ item }) => (
          <View style={[styles.row, item.mine ? styles.right : styles.left]}>
            <View style={[styles.bubble, item.mine ? styles.mine : styles.them]}>
              <AppText>{item.text}</AppText>
            </View>
          </View>
        )}
      />

      <View style={styles.composer}>
        <TextInput
          style={styles.input}
          placeholder="Message..."
          placeholderTextColor={colors.textMuted}
          value={input}
          onChangeText={setInput}
        />
        <TouchableOpacity style={styles.send} onPress={send}>
          <AppText>➤</AppText>
        </TouchableOpacity>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { fontSize: 18, fontWeight: "700", marginVertical: spacing.md },
  row: { flexDirection: "row", marginVertical: 4 },
  left: { justifyContent: "flex-start" },
  right: { justifyContent: "flex-end" },
  bubble: {
    padding: spacing.md,
    borderRadius: 16,
    maxWidth: "70%",
  },
  mine: { backgroundColor: colors.primary },
  them: { backgroundColor: colors.card },
  composer: {
    flexDirection: "row",
    paddingVertical: spacing.md,
    borderTopWidth: 1,
    borderColor: colors.border,
  },
  input: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 50,
    paddingHorizontal: spacing.md,
    color: colors.text,
  },
  send: {
    marginLeft: spacing.sm,
    backgroundColor: colors.primary,
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
  },
});
