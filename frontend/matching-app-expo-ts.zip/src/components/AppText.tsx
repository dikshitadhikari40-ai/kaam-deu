import React, { ReactNode } from "react";
import { Text, StyleSheet, TextStyle } from "react-native";
import { colors } from "../theme/colors";

type Props = {
  children: ReactNode;
  style?: TextStyle | TextStyle[];
};

export default function AppText({ children, style }: Props) {
  return <Text style={[styles.text, style]}>{children}</Text>;
}

const styles = StyleSheet.create({
  text: {
    color: colors.text,
  },
});
