export const colors = {
  primary: "#FF5263",
  background: "#0A0B0E",
  card: "#151821",
  text: "#FFFFFF",
  textMuted: "#9BA0B5",
  border: "#262A36",
};
