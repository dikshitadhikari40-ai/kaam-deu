import React, { useState } from "react";
import { View, StyleSheet, Image } from "react-native";
import ScreenContainer from "../components/ScreenContainer";
import AppText from "../components/AppText";
import AppButton from "../components/AppButton";
import { spacing } from "../theme/spacing";

export default function LoginScreen({ navigation }) {
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = () => {
    setLoading(true);
    setTimeout(() => {
      navigation.replace("MainTabs");
      setLoading(false);
    }, 1000);
  };

  return (
    <ScreenContainer>
      <View style={styles.top}>
        <Image
          source={{ uri: "https://placehold.co/100x100" }}
          style={styles.logo}
        />
        <AppText style={styles.tag}>Find your kind of people.</AppText>
      </View>

      <View style={styles.bottom}>
        <AppButton title="Continue with Google" loading={loading} onPress={handleGoogleLogin} />
        <AppText style={styles.small}>We never store your Google password.</AppText>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  top: {
    alignItems: "center",
    marginTop: spacing.xl,
  },
  logo: {
    width: 100,
    height: 100,
    borderRadius: 20,
    marginBottom: spacing.md,
  },
  tag: {
    fontSize: 20,
    fontWeight: "700",
  },
  bottom: {
    marginTop: "auto",
    paddingBottom: spacing.xl,
  },
  small: {
    fontSize: 12,
    textAlign: "center",
    marginTop: spacing.sm,
  },
});
