import React from "react";
import { SafeAreaView, StyleSheet } from "react-native";
import { colors } from "../theme/colors";
import { spacing } from "../theme/spacing";

export default function ScreenContainer({ children }) {
  return (
    <SafeAreaView style={styles.safe}>
      <SafeAreaView style={styles.inner}>{children}</SafeAreaView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
  },
  inner: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },
});
